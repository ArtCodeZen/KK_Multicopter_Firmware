HW Version 2.1
SW Version 1.9S3 With Spektrum (R) Satellite Support
Steveis

Warnings:

i)  Firmware will reset all settings
ii) Stick scaling and P&I gains need to be changed if you change the MPU6050 setting

Minor bug(s) corrected: 

i)  Tidied up I2C routine for burst reading of sensor data
ii) More accurate battery voltage - slightly adjusted from 1.9S2 to read the same as my KK2.0
iii)Corrected low voltage alarm calculation
iv) Corrected code to get an extra 1 bit of resolution on gyro and acc
v)  Input Sliders now work with CPPM or Satellite receivers

Addition(s): 

i)  Added support for Spektrum (R) Satellite and clones (See note below)
ii) Added more debug items
iii)Plain english max min Gyro rate and Acc values saved in menu "Sensor Max Min" when armed and SL off - use as an indicator
iv) 1.9S3 allows you to clear the max min values and fly again,=.  Before, you had to power cycle the KK2.1


*
Supports Spektrum(R) satellite with Tarot cable
Tested with Spektrum AR7/8000 DSM2 satellite and Orange R100 Satellite
Only supports 10 bit with all data in 1 frame 
Only supports 7 channels
Uses Throttle input for Tarot cable
Hold buttons 2&3 on power up to enter binding mode
If you switch between CPPM, Sat or normal receivers, power cycle the KK2.1
Debug lists 16 frame bytes from satellite - you'll know if there are 2 frames of data (so bind again).
KK2.1 Settings: -
You will need to set "Sat or CPPM" to "Yes" in Mode Settings
You will need to assign the channels correctly in Sat-CPPM Channels as  A=2,E=3,T=1,R=4,Aux=5

Many thanks to David Thompson of OpenAero(2) fame

